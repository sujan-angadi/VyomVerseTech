#!/bin/bash

APP_NAME="SwapShastra"
VERSION="1.0"
INSTALL_BASE="$HOME/.local/share/swapshastra"
INSTALL_DIR="$INSTALL_BASE/$VERSION"
DESKTOP_FILE="$HOME/.local/share/applications/${APP_NAME}_${VERSION}.desktop"

# Get current script's directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXEC_SRC="$SCRIPT_DIR/dist/SwapShastra_${VERSION}"
ICON_SRC="$SCRIPT_DIR/icon/swap_ico.jpeg"

# Destination
EXEC_DEST="$INSTALL_DIR/SwapShastra_${VERSION}"
ICON_DEST="$INSTALL_DIR/swap_ico.jpeg"

echo "Installing $APP_NAME version $VERSION..."
sleep 2

# Make install dir
mkdir -p "$INSTALL_DIR"
mkdir -p "$HOME/.local/share/applications"

# Copy files
cp "$EXEC_SRC" "$EXEC_DEST" || { echo "Executable not found. Aborting."; exit 1; }
cp "$ICON_SRC" "$ICON_DEST" || { echo "Icon not found. Aborting."; exit 1; }
chmod +x "$EXEC_DEST"

# Create desktop entry
cat > "$DESKTOP_FILE" <<EOL
[Desktop Entry]
Name=$APP_NAME $VERSION
Comment=Memory Swapping Application
Exec=$EXEC_DEST
Icon=$ICON_DEST
Terminal=false
Type=Application
Categories=Utility;
EOL

chmod +x "$DESKTOP_FILE"

echo "$APP_NAME $VERSION installed successfully!"

