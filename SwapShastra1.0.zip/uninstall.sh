#!/bin/bash

APP_NAME="SwapShastra"
DESKTOP_FILE="$HOME/.local/share/applications/${APP_NAME}.desktop"
EXEC_PATH="$HOME/.local/share/applications/SwapShastra_1.0"
ICON_PATH="$HOME/.local/share/icons/swap_ico.jpeg"

echo "Uninstalling SwapShastra"

# Sleep to simulate processing time
sleep 2

# Remove desktop file
if [ -f "$DESKTOP_FILE" ]; then
    rm "$DESKTOP_FILE"
    echo "Removed desktop entry."
else
    echo "Desktop entry not found."
fi

# Remove the copied executable
if [ -f "$EXEC_PATH" ]; then
    rm "$EXEC_PATH"
    echo "Removed application executable."
else
    echo "Executable not found."
fi

# Remove the icon
if [ -f "$ICON_PATH" ]; then
    rm "$ICON_PATH"
    echo "Removed application icon."
else
    echo "Icon not found."
fi

echo "$APP_NAME Uninstalled Successfully!! LOL BUT WHY??"
	
