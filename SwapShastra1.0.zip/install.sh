#!/bin/bash

APP_NAME="SwapShastra"
LOAD_EXEC_PATH="$HOME/Downloads/SwapShastra1.0/dist/SwapShastra_1.0"
LOAD_ICON_PATH="$HOME/Downloads/SwapShastra1.0/icon/swap_ico.jpeg"
DESKTOP_FILE="$HOME/.local/share/applications/${APP_NAME}.desktop"


echo "Installing SwapShastra"

sleep 2

mkdir -p ~/.local/share/applications
mkdir -p ~/.local/share/icons

cp "$LOAD_EXEC_PATH" ~/.local/share/applications/
cp "$LOAD_ICON_PATH" ~/.local/share/icons/

EXEC_PATH="$HOME/.local/share/applications/SwapShastra_1.0"
ICON_PATH="$HOME/.local/share/icons/swap_ico.jpeg"

cat > "$DESKTOP_FILE" <<EOL
[Desktop Entry]
Name=$APP_NAME
Comment=Memory Swapping Application
Exec=$EXEC_PATH
Icon=$ICON_PATH
Terminal=false
Type=Application
Categories=Utility;
EOL

chmod +x "$DESKTOP_FILE"

echo "$APP_NAME Installed Successfully!!"

