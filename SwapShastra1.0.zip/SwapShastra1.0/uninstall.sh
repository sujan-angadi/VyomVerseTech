#!/bin/bash

APP_NAME="SwapShastra"
INSTALL_BASE="$HOME/.local/share/swapshastra"
DESKTOP_DIR="$HOME/.local/share/applications"




echo "Uninstalling $APP_NAME..."
sleep 2


rm -rf "$INSTALL_BASE"
find "$DESKTOP_DIR" -name "${APP_NAME}_*.desktop" -exec rm {} \;

echo "All versions of $APP_NAME uninstalled successfully!!"
exit 0



echo "Uninstalling $APP_NAME..."
sleep 2

INSTALL_DIR="${INSTALL_BASE}"
DESKTOP_FILE="${DESKTOP_DIR}/${APP_NAME}.desktop"


if [ -f "$DESKTOP_FILE" ]; then
    rm "$DESKTOP_FILE"
    echo "Removed desktop entry."
else
    echo "Desktop entry not found."
fi

if [ -d "$INSTALL_DIR" ]; then
    rm -rf "$INSTALL_DIR"
    echo "Removed application files"
else
    echo "No installation found"
fi

echo "$APP_NAME uninstalled successfully!! LOL BUT WHY??"
#!/bin/bash

APP_NAME="SwapShastra"
DESKTOP_FILE="$HOME/.local/share/applications/${APP_NAME}.desktop"
EXEC_PATH="$HOME/.local/share/applications/SwapShastra_1.0"
ICON_PATH="$HOME/.local/share/icons/swap_ico.jpeg"

echo "Uninstalling SwapShastra"


sleep 2


if [ -f "$DESKTOP_FILE" ]; then
    rm "$DESKTOP_FILE"
    echo "Removed desktop entry."
else
    echo "Desktop entry not found."
fi


if [ -f "$EXEC_PATH" ]; then
    rm "$EXEC_PATH"
    echo "Removed application executable."
else
    echo "Executable not found."
fi


if [ -f "$ICON_PATH" ]; then
    rm "$ICON_PATH"
    echo "Removed application icon."
else
    echo "Icon not found."
fi

echo "$APP_NAME Uninstalled Successfully!! LOL BUT WHY??"
	
